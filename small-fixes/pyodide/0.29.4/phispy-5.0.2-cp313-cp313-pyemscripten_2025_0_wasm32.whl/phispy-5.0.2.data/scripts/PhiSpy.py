#!python

import PhiSpyModules


if __name__== "__main__":
    PhiSpyModules.run()
