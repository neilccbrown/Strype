"""
API for HaloCatalog frontend.




"""
