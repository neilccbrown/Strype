<template>
  <div id="app">
    <Frame v-bind:id="1" type="if" v-bind:parent="3"/>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import Frame from './components/Frames/Frame.vue';
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue';

export default Vue.extend({
  name: 'App',
  components: {
    Frame
  }
});
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
