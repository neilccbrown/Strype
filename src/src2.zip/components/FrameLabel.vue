<template>
    <div>
        <div v-for="item in labels" v-bind:key="item.label + parent">
            {{item.label}} 
            <EditableSlot v-if="item.slot" default-text="Default display text"/>
        </div>
    </div>
</template>



<script lang="ts">

//////////////////////
//      Imports     //
//////////////////////
import Vue from 'vue';
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue';
import EditableSlot from './EditableSlot.vue';


//////////////////////
//     Component    //
//////////////////////
export default Vue.extend({
    name: 'FrameLabel',
    
    components: 
    {
        EditableSlot
    },

    props: 
    {
        // We need an array of labels in the case there are more than one labels in the frame (e.g. `with` ... `as ... )
        labels : Array,
        parent: Number
    }

});
</script>