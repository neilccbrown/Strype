import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
    state: 
    {
        frames: 
        [
            { 
                name : "if",
                labels : [{label :'if' , slot : true} , {label :':' , slot : false}]
            }
        ]
    },
    getters:
    {
        getLabelsByName: (state, type: string) => 
        {
            return state.frames.find(o => o.name === type);
        }
        // getLabelsByName: (state) => (type:string) => 
        // {
        //     return state.frames.find(o => o.name == type);
        // }
        // getLabelsByName(state) {
        //     return (type:string) => state.frames.find(o => o.name === type);
        //     }
    },
    mutations: 
    {
    
    },
    actions: 
    {
    
    },
    modules: 
    {
    
    }
})
