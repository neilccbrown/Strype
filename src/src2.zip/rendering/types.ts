// Type Definitions

// export interface if_frame 
// {
//     isBlock: boolean;
//     parent: string | null;
// } 

// export type stament_frame = 